using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WyszukiwanieLinioweBinarne
{
    class Program
    {
        static uint liczbaDostepow;
        static uint Liniowe(uint[] tab, uint szukany)
        {
            for(uint i=0;i<tab.Count();i++)
            {
                liczbaDostepow++;
                if (tab[i]==szukany)
                {
                    return i;
                }
            }
            return 0;
        }
        static uint Binarne(uint[] tab, uint szukany)
        {
            uint poczatek = 0, koniec = (uint)tab.Count() - 1;
            while (poczatek < koniec)
            {
                uint srodek = (poczatek + koniec) / 2;
                liczbaDostepow++;
                if (tab[srodek] < szukany)
                {
                    poczatek = srodek + 1;
                }
                else if(tab[srodek] > szukany)
                {
                    koniec = srodek;
                }
                else
                {
                    return srodek;
                }
            }
            if (tab[poczatek] == szukany)
            {
                return poczatek;
            }
            else
            {
                return 0;
            }
            
        }
        static void Main(string[] args)
        {
            var watch = new System.Diagnostics.Stopwatch();
            //pomiar czasu
            uint[] tab = new uint[268435456];
            for (uint i = 0; i < tab.Count(); i++)
            {
                tab[i] = i;
            }
            double srednia = 0, sredniaCzasowa = 0;
            uint ilosc = 0;

            Console.WriteLine("Wyszukiwanie binarne");
            Console.WriteLine("\t\t\tLiczba dostepow\t\tCzas");
            Binarne(tab, 0);
            for (uint i = 2; i <= tab.Count(); i *= 2)
            {
                ilosc++;
                liczbaDostepow = 0;
                uint szukany = (uint)(tab.Count() - 1) / i;
                watch.Restart(); 
                Binarne(tab, szukany);
                watch.Stop();
                srednia += liczbaDostepow * i / 2;
                sredniaCzasowa += watch.ElapsedTicks;
                Console.Write("Element " + szukany + "\t");
                if (szukany < 10000000)
                {
                    Console.Write("\t");
                }
                Console.WriteLine(liczbaDostepow + "\t\t\t" + watch.ElapsedTicks);
            }
            liczbaDostepow = 0;
            watch.Restart();
            Binarne(tab, (uint)tab.Count()-1);
            watch.Stop();
            sredniaCzasowa /= ilosc;
            srednia /= tab.Count();
            Console.WriteLine("Średnia" + "\t\t\t" + srednia + "\t" + sredniaCzasowa);
            Console.WriteLine("Maksymalna" + "\t\t" + liczbaDostepow + "\t\t\t" + watch.ElapsedTicks);
            Console.ReadKey();
            //wyszukiwanie binarne

            ilosc = 0;
            srednia = 0;
            sredniaCzasowa = 0;
            Console.WriteLine("Wyszukiwanie liniowe");
            Console.WriteLine("\t\t\tLiczba dostepow\t\tCzas");
            for (uint i = 1; i < tab.Count(); i += (uint)tab.Count()/16)
            {
                ilosc++;
                liczbaDostepow = 0;
                uint szukany = i-1;
                watch.Restart();
                Liniowe(tab, szukany);
                watch.Stop();
                srednia += liczbaDostepow;
                sredniaCzasowa += watch.ElapsedTicks;
                Console.Write("Element " + szukany + "\t");
                if (szukany < 10000000)
                {
                    Console.Write("\t");
                }
                Console.Write(liczbaDostepow + "\t\t");
                if (liczbaDostepow < 10000000)
                {
                    Console.Write("\t");
                }
                Console.WriteLine(watch.ElapsedTicks);
            }
             //wyszukiwanie liniowe

             
            sredniaCzasowa /= ilosc;
            srednia /= ilosc;
            liczbaDostepow = 0;
            watch.Restart();
            Liniowe(tab, (uint)tab.Count() - 1);
            watch.Stop();
            Console.WriteLine("Średnia" + "\t\t\t" + srednia + "\t" + sredniaCzasowa);
            Console.WriteLine("Maksymalna" + "\t\t" + liczbaDostepow + "\t\t\t" + watch.ElapsedTicks);
            Console.ReadKey();
        }
    }
}
